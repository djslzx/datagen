from .eggy import *

__doc__ = eggy.__doc__
if hasattr(eggy, "__all__"):
    __all__ = eggy.__all__